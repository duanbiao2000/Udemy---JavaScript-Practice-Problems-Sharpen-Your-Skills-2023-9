
const determineAgeFunction = function(day, month, year) {
  
  console.log(`You are ${years} years and ${days} days old. Which is ${hours} hours OR ${minutes} minutes OR ${seconds} seconds.`);
};



// Testing determineAgeFunction...

determineAgeFunction(25,5,1965);
determineAgeFunction(1,1,1970);
determineAgeFunction(03,09,2001);
determineAgeFunction(27,04,2023);
